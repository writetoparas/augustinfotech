 jQuery( document ).ready(function() { 
   jQuery(".referral_code").on("keyup", function(){ 
	var input = jQuery(this).val();
	if(input != ''){
		var data= {		
			'action': 'referral_code_data',
			'referral_code': input,
			'nonce': ajax_object.nonce
		}
		jQuery.post(ajax_object.url, data, function(response){
			//alert(response);
			var data = response;
			if(data = 'Good to Go'){
				jQuery(".close").css("display", "none");
				jQuery(".checkmark").css("display", "block");
				
			} else {
				
				jQuery(".close").css("display", "block");
				jQuery(".checkmark").css("display", "none");
			} 
			
			
		});
	}
   
   });
 
 });