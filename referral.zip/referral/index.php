<?php
/*
Plugin Name: Referral
Author: Paras
Description: Registration from with referral text field.
*/


add_action('admin_menu', 'custom_menu');

function custom_menu(){
	
	add_menu_page(
	'Referral Form Page',
	'Referral Form',
	'edit_posts',
	'referral_form',
	'referral_callback',
	'dashicons-media-spreadsheet'
	);
	
}

function referral_callback(){
 
require_once "referral-table.php"; 
	
}

function registration_form_data(){
	
 if (!is_user_logged_in()){
	 
	 $registration_enabled = get_option('users_can_register');
	 
	 if($registration_enabled) {
		 
		return $output = registration_form_layout();
		
	 } else {
		 
		return $output  = "Enable User Registartion Option";
	 }
	 
	 
 }
	
}
 add_shortcode('register_form', 'registration_form_data');
 
 
 function registration_form_layout(){
	 
	 ob_start();
	?>
	 <h2>Registration Form</h2>
	 
	 <form id="registration_form" method="POST" action="">
	    <fieldset>
		  <p>
		  <label><?php _e("First Name");?></label>
		  <input type="text" placeholder="First Name" name="first_name" id="first_name" class="first_name" required>
		  </p>
		  
		  <p>
		  <label><?php _e("Last Name");?></label>
		  <input type="text" placeholder="Last Name" name="last_name" id="last_name" class="last_name" required>
		  </p>
		  
		  <p>
		  <label><?php _e("Email");?></label>
		  <input type="email" placeholder="Email ID" name="email_id" id="email_id" class="email_id" required>
		  </p>
		  
		  <p>
		  <label><?php _e("Password");?></label>
		  <input type="password" placeholder="Password" name="password" id="password" class="password" required>
		  </p>
		  
		   <p>
		  <label><?php _e("Referral Code");?></label>
		  <input type="text" placeholder="Referral Code" name="referral_code" id="referral_code" class="referral_code" required>
		  <div class="checkmark" style="display: inline-block;transform: rotate(45deg);height: 15px;width: 8px;border-bottom: 5px solid #78b13f;border-right: 5px solid #78b13f;margin-top: -42px;float: inline-end;margin-right: 48%; display:none;"></div>
		  <span class="close" style="font-size: 60px;font-weight: bold;color: #f00; display: none;margin-top: -42px;float: inline-end;margin-right: 48%;">&times;</span>  
		  </p>
		  
		   <p>
		  <input type="hidden" name="noce_code" value="<?php echo wp_create_nonce('noce_code');?>">
		  <input type="submit" value="Register">
		  </p>
		  
	    </fieldset>
	 
	 </form>
	 
	<?php 
	return  ob_get_clean();
 }
 
function add_new_user(){
	 if(isset($_POST['email_id']) && wp_verify_nonce($_POST['noce_code'], 'noce_code')) {
		 
		 $user_login = $_POST['email_id'];
		 $first_name = $_POST['first_name'];
		 $last_name = $_POST['last_name'];
		 $user_email = $_POST['email_id'];
		 $user_pass = $_POST['password'];
		 $referral = $_POST['referral_code'];
		 
		 $newuser = wp_insert_user(
		                    array(
							'user_login' =>  $user_login,
							'first_name' => $first_name,
							'last_name' => $last_name,
							'user_email' => $user_email,
							'user_pass' => $user_pass,
							'role' => 'subscriber'
							
							
							)
		 );
		// print_r($newuser);
		 //if($newuser){
			
			 update_user_meta($newuser, 'referral_code', $referral);
			
			 wp_set_current_user($user_login, $user_pass);
			 do_action('wp_login', $user_login);
			 wp_redirect(home_url());
			 
		 }
		 
	 }	

add_action('init', 'add_new_user');

function ajax_enqueuescripts() {
	
    wp_register_script('custom-script', plugin_dir_url( __FILE__ ) .'custom.js', array('jquery'));
	
	$script_data = array(
	'url'=> admin_url('admin-ajax.php'),
	'nonce' => wp_create_nonce('search_referr_nonce')
	);
	
    wp_localize_script('custom-script', 'ajax_object', $script_data);
	
	wp_enqueue_script('custom-script');
}

   add_action('wp_enqueue_scripts', 'ajax_enqueuescripts');
   add_action('wp_ajax_nopriv_referral_code_data', 'referral_code_data' );
   add_action('wp_ajax_referral_code_data', 'referral_code_data' );

function referral_code_data(){
	
	check_ajax_referer('search_referr_nonce','nonce');
	$input = $_POST['referral_code'];

    $args = array(
	'meta_key' => 'referral_code',
	'meta_value' => $input
	);
	
	$query = new WP_User_Query($args);
	$count = $query->get_total();
	if($count > 0) {
		echo "Referral Code Already Used";
	} else {
		echo "Good to Go";
	}
}

?>