<?php

if(!class_exists('WP_List_Table')) {

    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );

}



class TT_Orders_List_Table extends WP_List_Table {

    function __construct() {

        parent::__construct( array(

            'singular'  => 'ID',

            'plural'    => 'ID',

            'ajax'      => false

        ));

    }



    function column_default($item, $column_name) {

        switch($column_name) {

            case 'id':

            case 'name':

            case 'referral':

            //case 'date':

                return $item->$column_name;

            default:

                return print_r($item,true); //Show the whole array for troubleshooting purposes

        }

    }

    function column_user_firstname($item) {
        $actions = array(
            'delete'    => sprintf('<a href="users.php?page=%s&action=delete&id=%s&wp_http_referer=%s">Delete</a>', $_REQUEST['page'], $item->id, 'wp-admin/users.php?page='.$_REQUEST['page']),
        );

        return sprintf( '%1$s <span style="color:silver">(ID:%2$s)</span>%3$s', /*$1%s*/ $item->name, /*$2%s*/ $item->id, /*$3%s*/ $this->row_actions($actions));

    }



    function column_cb($item) {

        return sprintf( '<input type="checkbox" name="%1$s[]" value="%2$s" />', /*$1%s*/ $this->_args['singular'], $item->ID );

    }



    function get_columns() {

        $columns = array(

            'cb'                => '<input type="checkbox" />',
			
            'id'    => 'User ID',
            
			'name'    => 'User Name',

            'referral'        => 'Referral Code'

        );

        return $columns;

    }



    function get_sortable_columns() {

        $sortable_columns = array(

			
			'id'    => array('wp_users.ID',true),

            'name'        => array('wp_users.display_name',true),

            'referral'        => array('wp_users.display_name',false)


        );

        return $sortable_columns;

    }


    function get_bulk_actions() {

        $actions = array(

            'delete'    => 'Delete'

        );

        return $actions;

    }


    function process_bulk_action() {

        global $wpdb;

        if( 'delete'===$this->current_action() ) {

            $id = $_REQUEST['id'];

            $ids = '';

            if(is_array($id)) {

                foreach($id as $k=>$v) {

                    $ids .= $v . ",";

                }

                $ids = substr($ids, 0, -1);

            } else {

                $ids = $id;

            }



            if($ids != '') {
                $wpdb->query( "DELETE FROM `".$wpdb->prefix."usermeta` WHERE id  IN ($ids)" );

            }

        }

    }


    function prepare_items() {

        global $wpdb;

        $query = "SELECT wp_users.ID AS 'id', wp_users.display_name AS 'name', meta_value AS 'referral' FROM wp_usermeta JOIN wp_users ON wp_usermeta.user_id=wp_users.ID WHERE `meta_key` = 'referral_code' AND `meta_value` LIKE '%%' ORDER BY wp_users.ID";
                    //echo $query;
                    //exit;
        $orderby = !empty($_GET["orderby"]) ? mysql_real_escape_string($_GET["orderby"]) : 'DESC';

        $order = !empty($_GET["order"]) ? mysql_real_escape_string($_GET["order"]) : '';

        if(!empty($orderby) & !empty($order)) { $query.=' ORDER BY '.$orderby.' '.$order; }

        $totalitems = $wpdb->query($query);

        $perpage = 15;

        $hidden = array();

        $paged = !empty($_GET["paged"]) ? mysql_real_escape_string($_GET["paged"]) : '';

        if(empty($paged) || !is_numeric($paged) || $paged<=0 ) { $paged=1; }

        $totalpages = ceil($totalitems/$perpage);

        if(!empty($paged) && !empty($perpage)) {

            $offset=($paged-1)*$perpage;

            $query.=' LIMIT '.(int)$offset.','.(int)$perpage;

        }



        $this->set_pagination_args( array(

            "total_items" => $totalitems,

            "total_pages" => $totalpages,

            "per_page" => $perpage,

        ));



        $columns = $this->get_columns();

        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->process_bulk_action();

        $this->items = $wpdb->get_results($query);

        if(!empty($this->items)) {

            $items = array();

            foreach($this->items as $item) {

                $items[] = $item;

            }

            $this->items = $items;
//print_r($items);
        }

    }

}

$ordersListTable = new TT_Orders_List_Table();

$ordersListTable->prepare_items();

?>  

<div class="wrap">

    <div id="icon-users" class="icon32"><br/></div>

    <h2>Form Data</h2>

    <form id="posts-filter" method="get">

        <input type="hidden" name="post_type" value="<?php// echo $_REQUEST['post_type'] ?>" />

        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />

        <?php $ordersListTable->display(); ?>

    </form>

</div>